# EnviroMe

Elle Hacks 2020 - Deloitte Best Pitch Recipient.  
EnviroMe is your sustainability tracker that enables you to monitor the environmental impact and carbon footprint of the everyday products you buy and use.

